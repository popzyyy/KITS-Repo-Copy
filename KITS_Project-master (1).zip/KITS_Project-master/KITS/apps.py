from django.apps import AppConfig


class KitsConfig(AppConfig):
    name = 'KITS'
